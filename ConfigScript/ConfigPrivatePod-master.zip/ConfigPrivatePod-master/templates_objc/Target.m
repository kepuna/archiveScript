//
//  Target___ProjectName__.m
//  __ProjectName__
//
//  Created by casa on 2020/3/9.
//  Copyright © 2020 casa. All rights reserved.
//

#import "Target___ProjectName__.h"

@implementation Target___ProjectName__

- (NSString *)Action_test:(NSDictionary *)params
{
    return @"success";
}

@end
