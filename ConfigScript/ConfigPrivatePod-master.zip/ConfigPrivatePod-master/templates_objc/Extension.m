//
//  CTMediator+__ProjectName__.m
//  __ProjectName__
//
//  Created by casa on 2020/3/9.
//  Copyright © 2020 casa. All rights reserved.
//

#import "CTMediator+__ProjectName__.h"

@implementation CTMediator (__ProjectName__)

- (NSString *)__ProjectName___test
{
    NSString *result = (NSString *)[self performTarget:@"__ProjectName__" action:@"test" params:nil shouldCacheTarget:NO];
    return result;
}

@end
