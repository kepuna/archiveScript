//
//  CTMediator+__ProjectName__.h
//  __ProjectName__
//
//  Created by casa's script 
//  Copyright © 2020 casa. All rights reserved.
//

#import <CTMediator/CTMediator.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTMediator (__ProjectName__)

- (NSString *)__ProjectName___test;
    
@end

NS_ASSUME_NONNULL_END
